
import './App.css';
import React, {useState,useEffect} from "react";
import Axios from "axios";
function App() {

  const[name,setname] = useState('');
  const[division,setdivision] = useState([]);
  const[mobile,setmobile] = useState('');
  const[image,setimage] = useState('');
  const[infolist,setinfolist] = useState('');
  useEffect(()=>{
       Axios.get('http://localhost:3002/api/get').then((response)=>{
         setinfolist(response.data)
       })
  },[])
  const submitvalues = () =>{
      Axios.post("http://localhost:3002/api/insert",{
        Name:name,
        division:division,
        mobileno:mobile,
        image:image,
      });
      setinfolist([...infolist,{Name:name,mobileno:mobile,division:division}]);
      
  };
  const deletevalue = (name) =>{
    Axios.delete(`http://localhost:3002/api/delete/${name}`);
  }
  return (
    <div className="App">
       <div className='main'>
         <div className='nav'>
          <h1>Vehicle Recognition System</h1>
          <p>A smart way to store vehicle information which uses ANPR technoloy</p>
         </div>
        
        <div className='form text'>
            <label for='name'>Enter name:</label>
            <input type="text" name="name" id="name" onChange={(e)=>{
                    setname(e.target.value)
            }}></input>
            <label for='division'>Enter division:</label>
            
            <input type="text" name="division" id='division' placeholder='eg: SE 06' onChange={(e)=>{
                setdivision(e.target.value)
            }}></input>
            
            <label for='number'>Enter mobile number:</label>
            <input type="text" name="number" id="number" onChange={(e)=>{
              setmobile(e.target.value)
            }}></input>
            {/* <label for='number plate'>Enter number plate of vehicle:</label>
            <input type="text" name="number" id="name"></input> */}

            <div class="mb-3">
               <label for="formFileSm" class="form-label">Upload Image</label>
              <input class="form-control form-control-sm" id="name" type="file" onChange={(e)=>{
                setimage(e.target.value)
              }}></input>
            </div>
            <button onClick={submitvalues}>Submit</button>

            {/* {infolist.map((val)=>{
                return ( <div className="card">
                  <h4>{val.Name}</h4>
                  <p> {val.mobileno} | {val.division} </p>

                  <button onClick={()=>{deletevalue(val.Name)}}>delete</button>
                  </div>
                );
            })} */}
        </div>
        
    </div> 
     
    </div>
  );
}

export default App;
